<?php return array (
  'users.register' => 'App\\Http\\Livewire\\Users\\Register',
);