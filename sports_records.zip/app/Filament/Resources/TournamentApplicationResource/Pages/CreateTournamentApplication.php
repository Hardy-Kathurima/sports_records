<?php

namespace App\Filament\Resources\TournamentApplicationResource\Pages;

use App\Filament\Resources\TournamentApplicationResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTournamentApplication extends CreateRecord
{
    protected static string $resource = TournamentApplicationResource::class;
}
