import FormsAlpinePlugin from '../../vendor/filament/forms/dist/module.esm'
import Alpine from 'alpinejs'



Alpine.plugin(FormsAlpinePlugin)
window.Alpine = Alpine
Alpine.start()
